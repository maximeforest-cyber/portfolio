﻿using System;

namespace AP7IpEtSousRéseauxForestMaxime
{
    partial class Accueil
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.IP_box = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_accueil = new System.Windows.Forms.Button();
            this.lb_iperreur = new System.Windows.Forms.Label();
            this.lb_cidrerreur = new System.Windows.Forms.Label();
            this.lb_ipbinaire = new System.Windows.Forms.Label();
            this.CIDR_val = new System.Windows.Forms.NumericUpDown();
            this.btn_suite = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.CIDR_val)).BeginInit();
            this.SuspendLayout();
            // 
            // IP_box
            // 
            this.IP_box.Location = new System.Drawing.Point(329, 106);
            this.IP_box.Name = "IP_box";
            this.IP_box.Size = new System.Drawing.Size(132, 26);
            this.IP_box.TabIndex = 0;
            this.IP_box.TextChanged += new System.EventHandler(this.IP_box_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(297, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(212, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "Saississez l\'adresse IP";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(307, 171);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(178, 25);
            this.label2.TabIndex = 3;
            this.label2.Text = "Saississez le CIDR";
            // 
            // btn_accueil
            // 
            this.btn_accueil.Location = new System.Drawing.Point(312, 285);
            this.btn_accueil.Name = "btn_accueil";
            this.btn_accueil.Size = new System.Drawing.Size(162, 33);
            this.btn_accueil.TabIndex = 4;
            this.btn_accueil.Text = "Calculer";
            this.btn_accueil.UseVisualStyleBackColor = true;
            this.btn_accueil.Click += new System.EventHandler(this.btn_accueil_Click);
            // 
            // lb_iperreur
            // 
            this.lb_iperreur.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_iperreur.Location = new System.Drawing.Point(502, 93);
            this.lb_iperreur.Name = "lb_iperreur";
            this.lb_iperreur.Size = new System.Drawing.Size(286, 55);
            this.lb_iperreur.TabIndex = 5;
            // 
            // lb_cidrerreur
            // 
            this.lb_cidrerreur.AutoSize = true;
            this.lb_cidrerreur.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_cidrerreur.Location = new System.Drawing.Point(502, 226);
            this.lb_cidrerreur.Name = "lb_cidrerreur";
            this.lb_cidrerreur.Size = new System.Drawing.Size(0, 25);
            this.lb_cidrerreur.TabIndex = 6;
            // 
            // lb_ipbinaire
            // 
            this.lb_ipbinaire.AutoSize = true;
            this.lb_ipbinaire.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_ipbinaire.Location = new System.Drawing.Point(96, 360);
            this.lb_ipbinaire.Name = "lb_ipbinaire";
            this.lb_ipbinaire.Size = new System.Drawing.Size(0, 25);
            this.lb_ipbinaire.TabIndex = 7;
            this.lb_ipbinaire.Click += new System.EventHandler(this.lb_ipbinaire_Click);
            // 
            // CIDR_val
            // 
            this.CIDR_val.Location = new System.Drawing.Point(329, 228);
            this.CIDR_val.Maximum = new decimal(new int[] {
            32,
            0,
            0,
            0});
            this.CIDR_val.Name = "CIDR_val";
            this.CIDR_val.Size = new System.Drawing.Size(132, 26);
            this.CIDR_val.TabIndex = 8;
            this.CIDR_val.ValueChanged += new System.EventHandler(this.CIDR_val_ValueChanged);
            // 
            // btn_suite
            // 
            this.btn_suite.Location = new System.Drawing.Point(312, 391);
            this.btn_suite.Name = "btn_suite";
            this.btn_suite.Size = new System.Drawing.Size(162, 32);
            this.btn_suite.TabIndex = 9;
            this.btn_suite.Text = "Suite";
            this.btn_suite.UseVisualStyleBackColor = true;
            this.btn_suite.Click += new System.EventHandler(this.btn_suite_Click);
            // 
            // Accueil
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_suite);
            this.Controls.Add(this.CIDR_val);
            this.Controls.Add(this.lb_ipbinaire);
            this.Controls.Add(this.lb_cidrerreur);
            this.Controls.Add(this.lb_iperreur);
            this.Controls.Add(this.btn_accueil);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.IP_box);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Name = "Accueil";
            this.Text = "Accueil";
            this.Load += new System.EventHandler(this.Accueil_Load);
            ((System.ComponentModel.ISupportInitialize)(this.CIDR_val)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void lb_ipbinaire_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void CIDR_box_TextChanged(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private System.Windows.Forms.TextBox IP_box;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_accueil;
        private System.Windows.Forms.Label lb_iperreur;
        private System.Windows.Forms.Label lb_cidrerreur;
        private System.Windows.Forms.Label lb_ipbinaire;
        private System.Windows.Forms.NumericUpDown CIDR_val;
        private System.Windows.Forms.Button btn_suite;
    }
}