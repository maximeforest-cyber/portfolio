﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AP7IpEtSousRéseauxForestMaxime
{
    public partial class Accueil : Form
    {
        public Accueil()
        {
            InitializeComponent();
        }
        private void IP_box_TextChanged(object sender, EventArgs e)
        {
            Globale.adresse_ip=IP_box.Text; // Stocke dans une variable publique l'adresse IP en décimal
        }
        private void btn_accueil_Click(object sender, EventArgs e)
        {
            // Sépare en tableau l'adresse IP par le '.'
            string[] partie_ip = Globale.adresse_ip.Split('.');
            string ipBinaire_final = ""; // Variable qui va stocker l'adresse ip en binaire
            Globale.partie_ip = partie_ip; // Stocke dans une variable publique l'adresse IP séparé
            // Adresse IP qui doit être composé de 4 valeurs
            if (partie_ip.Length == 4)
            {
                for (int i = 0; i < 4; i++) // Boucle de i < 4 pour traiter les 4 parties de l'adresse IP
                {
// Fonction qui vérifie si ce la text box est bien une adresse IP
                    if (IPAddress.TryParse(Globale.adresse_ip, out _))
                    {
                        // Fonction qui convertit une adresse décimale en adresse binaire
                            string ipBinaire = Convert.ToString(Int16.Parse(partie_ip[i]), 2).PadLeft(8, '0');

                            if (i == 3) // Traite la dernière valeur de l'adresse
                            {
                                ipBinaire_final += ipBinaire;
                                Globale.verife_form2 = true; // Autorise le passage au second form
                                lb_iperreur.Text = "";
                            }
                            else // Traite les autres valeurs de l'adresse
                            {
                                ipBinaire_final += ipBinaire + ".";
                            }

                        }
                    else // Cas où ce n'est pas une adresse IP valide
                    {
                        lb_iperreur.Text = "Erreur, ce n'est pas une adresse IP valide";
                        Globale.verife_form2 = false; // Bloque le passage à l'autre form
                        lb_ipbinaire.Text = "";

                    }
                }
                string[] partie_ip_binaire = ipBinaire_final.Split('.');
                if (partie_ip_binaire.Length == 4)
                {
                    lb_ipbinaire.Text = "Adresse IP en binaire :" + ipBinaire_final;
                    Globale.adresse_ip_binaire = ipBinaire_final;
                }

            }
            else // Cas où il n'y pas 4 valeurs dans l'adresse, donc qui n'est pas une adresse IP
            {
               lb_iperreur.Text = "Erreur, IP non reconnu";
                Globale.verife_form2 = false;
                lb_ipbinaire.Text = "";
            }
            if (Globale.verife_form2 == true) // Condition pour activer le bouton pour le second form
            {
                btn_suite.Enabled = true;
            }
            else // Condition pour désactiver le bouton pour le second form
            {
                btn_suite.Enabled = false;
            }
        }

        private void CIDR_val_ValueChanged(object sender, EventArgs e)
        {
            // Stocke la valeur du CIDR choisi dans une variable publique
            Globale.CIDR = (byte)CIDR_val.Value;
        }

        private void btn_suite_Click(object sender, EventArgs e)
        {
            // Bouton pour passer à l'autre form
            Etape2 etape2 = new Etape2();
            etape2.Show();
            this.Hide();
        }

        private void Accueil_Load(object sender, EventArgs e)
        {
            // Désactive de base le bouton pour aller à l'autre form
            btn_suite.Enabled = false;
        }
    }
    }
