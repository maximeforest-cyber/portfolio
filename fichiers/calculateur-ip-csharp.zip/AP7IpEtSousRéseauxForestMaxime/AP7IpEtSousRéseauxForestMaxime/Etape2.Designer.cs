﻿namespace AP7IpEtSousRéseauxForestMaxime
{
    partial class Etape2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_cidr_de_accueil = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_binaire = new System.Windows.Forms.Button();
            this.btn_decimale = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_adresseR = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.btn_nbhote = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.btn_classe = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.btn_nbSousReseaux = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.valeur_NvCIDR = new System.Windows.Forms.NumericUpDown();
            this.lb_CIDRerreur = new System.Windows.Forms.Label();
            this.btn_valideNvCIDR = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.valeur_NvCIDR)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_cidr_de_accueil
            // 
            this.lb_cidr_de_accueil.AutoSize = true;
            this.lb_cidr_de_accueil.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_cidr_de_accueil.Location = new System.Drawing.Point(320, 22);
            this.lb_cidr_de_accueil.Name = "lb_cidr_de_accueil";
            this.lb_cidr_de_accueil.Size = new System.Drawing.Size(169, 25);
            this.lb_cidr_de_accueil.TabIndex = 0;
            this.lb_cidr_de_accueil.Text = "Votre CIDR est 31";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(296, 22);
            this.label1.TabIndex = 1;
            this.label1.Text = "Masque de sous-réseau en binaire :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 133);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(313, 22);
            this.label2.TabIndex = 2;
            this.label2.Text = "Masque de sous-réseau en décimale :";
            // 
            // btn_binaire
            // 
            this.btn_binaire.Location = new System.Drawing.Point(314, 63);
            this.btn_binaire.Name = "btn_binaire";
            this.btn_binaire.Size = new System.Drawing.Size(80, 49);
            this.btn_binaire.TabIndex = 3;
            this.btn_binaire.Text = "Binaire";
            this.btn_binaire.UseVisualStyleBackColor = true;
            this.btn_binaire.Click += new System.EventHandler(this.btn_binaire_Click);
            // 
            // btn_decimale
            // 
            this.btn_decimale.Location = new System.Drawing.Point(331, 121);
            this.btn_decimale.Name = "btn_decimale";
            this.btn_decimale.Size = new System.Drawing.Size(83, 49);
            this.btn_decimale.TabIndex = 4;
            this.btn_decimale.Text = "Décimale";
            this.btn_decimale.UseVisualStyleBackColor = true;
            this.btn_decimale.Click += new System.EventHandler(this.btn_decimale_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 204);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(228, 22);
            this.label3.TabIndex = 5;
            this.label3.Text = "Adresse réseau principale :";
            // 
            // btn_adresseR
            // 
            this.btn_adresseR.Location = new System.Drawing.Point(246, 192);
            this.btn_adresseR.Name = "btn_adresseR";
            this.btn_adresseR.Size = new System.Drawing.Size(112, 49);
            this.btn_adresseR.TabIndex = 6;
            this.btn_adresseR.Text = "Adresse réseau";
            this.btn_adresseR.UseVisualStyleBackColor = true;
            this.btn_adresseR.Click += new System.EventHandler(this.btn_adresseR_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 274);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(226, 22);
            this.label4.TabIndex = 7;
            this.label4.Text = "Nombre d\'hôtes maximum :";
            // 
            // btn_nbhote
            // 
            this.btn_nbhote.Location = new System.Drawing.Point(246, 262);
            this.btn_nbhote.Name = "btn_nbhote";
            this.btn_nbhote.Size = new System.Drawing.Size(112, 49);
            this.btn_nbhote.TabIndex = 8;
            this.btn_nbhote.Text = "Nombre d\'hôtes";
            this.btn_nbhote.UseVisualStyleBackColor = true;
            this.btn_nbhote.Click += new System.EventHandler(this.btn_nbhote_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 335);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(198, 22);
            this.label5.TabIndex = 9;
            this.label5.Text = "Classe de l\'adresse IP :";
            // 
            // btn_classe
            // 
            this.btn_classe.Location = new System.Drawing.Point(216, 323);
            this.btn_classe.Name = "btn_classe";
            this.btn_classe.Size = new System.Drawing.Size(112, 49);
            this.btn_classe.TabIndex = 10;
            this.btn_classe.Text = "Classe";
            this.btn_classe.UseVisualStyleBackColor = true;
            this.btn_classe.Click += new System.EventHandler(this.btn_classe_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(12, 403);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(220, 22);
            this.label6.TabIndex = 11;
            this.label6.Text = "Nombre de sous réseaux :";
            // 
            // btn_nbSousReseaux
            // 
            this.btn_nbSousReseaux.Location = new System.Drawing.Point(238, 375);
            this.btn_nbSousReseaux.Name = "btn_nbSousReseaux";
            this.btn_nbSousReseaux.Size = new System.Drawing.Size(102, 80);
            this.btn_nbSousReseaux.TabIndex = 13;
            this.btn_nbSousReseaux.Text = "Nombre sous réseaux";
            this.btn_nbSousReseaux.UseVisualStyleBackColor = true;
            this.btn_nbSousReseaux.Click += new System.EventHandler(this.btn_nbSousReseaux_Click);
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(398, 185);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(205, 74);
            this.label7.TabIndex = 14;
            this.label7.Text = "Nombre de bits attribués pour le nouveau CIDR :";
            // 
            // valeur_NvCIDR
            // 
            this.valeur_NvCIDR.Location = new System.Drawing.Point(625, 200);
            this.valeur_NvCIDR.Name = "valeur_NvCIDR";
            this.valeur_NvCIDR.Size = new System.Drawing.Size(120, 26);
            this.valeur_NvCIDR.TabIndex = 15;
            this.valeur_NvCIDR.ValueChanged += new System.EventHandler(this.valeur_NvCIDR_ValueChanged);
            // 
            // lb_CIDRerreur
            // 
            this.lb_CIDRerreur.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_CIDRerreur.Location = new System.Drawing.Point(414, 316);
            this.lb_CIDRerreur.Name = "lb_CIDRerreur";
            this.lb_CIDRerreur.Size = new System.Drawing.Size(311, 56);
            this.lb_CIDRerreur.TabIndex = 16;
            // 
            // btn_valideNvCIDR
            // 
            this.btn_valideNvCIDR.Location = new System.Drawing.Point(504, 262);
            this.btn_valideNvCIDR.Name = "btn_valideNvCIDR";
            this.btn_valideNvCIDR.Size = new System.Drawing.Size(141, 34);
            this.btn_valideNvCIDR.TabIndex = 17;
            this.btn_valideNvCIDR.Text = "Valider";
            this.btn_valideNvCIDR.UseVisualStyleBackColor = true;
            this.btn_valideNvCIDR.Click += new System.EventHandler(this.btn_valideNvCIDR_Click);
            // 
            // Etape2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_valideNvCIDR);
            this.Controls.Add(this.lb_CIDRerreur);
            this.Controls.Add(this.valeur_NvCIDR);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btn_nbSousReseaux);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btn_classe);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btn_nbhote);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btn_adresseR);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btn_decimale);
            this.Controls.Add(this.btn_binaire);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lb_cidr_de_accueil);
            this.ForeColor = System.Drawing.Color.Black;
            this.Name = "Etape2";
            this.Text = "Etape2";
            this.Load += new System.EventHandler(this.Etape2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.valeur_NvCIDR)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_cidr_de_accueil;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_binaire;
        private System.Windows.Forms.Button btn_decimale;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_adresseR;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn_nbhote;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btn_classe;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btn_nbSousReseaux;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown valeur_NvCIDR;
        private System.Windows.Forms.Label lb_CIDRerreur;
        private System.Windows.Forms.Button btn_valideNvCIDR;
    }
}