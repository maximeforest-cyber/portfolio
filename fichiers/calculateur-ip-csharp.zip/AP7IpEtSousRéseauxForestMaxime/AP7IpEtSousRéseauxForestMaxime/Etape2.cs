﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AP7IpEtSousRéseauxForestMaxime
{
    public partial class Etape2 : Form
    {
        public Etape2()
        {
            InitializeComponent();
        }

        private void btn_binaire_Click(object sender, EventArgs e)
        {
            // Initialisation d'une variable temporaire pour ne pas toucher à la variable Globale.CIDR
            byte temp_cidr = Globale.CIDR; 
            string masque_binaire = "";
            for (int i = 0; i < 35; i++) // Boucle de i<35 car 4 octets + les 3 points dans une adresse
            {
                if (i == 8 || i == 17 || i == 26) // Les 3 points à rajouter dans une adresse binaire
                {
                    masque_binaire += '.';
                }
                else
                {
                    if (temp_cidr > 0) // Les bits=1 qu'on rajoute en fonction du CIDR
                    {
                        masque_binaire += 1;
                        temp_cidr -= 1;
                    }
                    else // temp_cidr=0 donc on a mis tous les bits=1, on met le reste en bits=0
                    {
                        masque_binaire += 0;
                    }
                }
            }
            MessageBox.Show("Votre masque sous-réseau en binaire est " + masque_binaire);
        }

        private void Etape2_Load(object sender, EventArgs e)
        {
            // Affiche le CIDR choisi avant dans le nouveau form
            lb_cidr_de_accueil.Text = "Votre CIDR est " + Globale.CIDR; 
            string masque_binaire = "";
            byte temp_cidr = Globale.CIDR;
            for (int i = 0; i < 35; i++)
            {
                if (i == 8 || i == 17 || i == 26)
                {
                    masque_binaire += '.';
                }
                else
                {
                    if (temp_cidr > 0)
                    {
                        masque_binaire += 1;
                        temp_cidr -= 1;
                    }
                    else
                    {
                        masque_binaire += 0;
                    }
                }
            }
            // Stocke la variable masque_binaire dans une variable publique pour l'utiliser plus tard
            Globale.masque_binaire = masque_binaire; 
        }

        private void btn_decimale_Click(object sender, EventArgs e)
        {
            byte temp_cidr2= Globale.CIDR;
            // Variable qui stockera l'adresse du masque en décimale
            string masque_decimale = ""; 
            // Sépare en tableau les parties binaire de l'adresse du masque
            string[] partie_binaire = Globale.masque_binaire.Split('.'); 

            for (int i = 0;i < 7; i++) // Boucle de i < 7 car 4 valeurs entières + les 3 points dans une adresse
            {
            if (i == 1 || i == 3 || i == 5) // Les 3 points à rajouter dans une adresse binaire
                {
                    masque_decimale += '.';
                }
            if (i == 0) // Première valeur de l'adresse
                {
                    masque_decimale+=Convert.ToByte(partie_binaire[0], 2);
                }
                if (i == 2) // Deuxième valeurs de l'adresse
                {
                    masque_decimale += Convert.ToByte(partie_binaire[1], 2);
                }
                if (i == 4) // Troisième valeurs de l'adresse
                {
                    masque_decimale += Convert.ToByte(partie_binaire[2], 2);
                }
                if (i == 6) // Quatrième valeurs de l'adresse
                {
                    masque_decimale += Convert.ToByte(partie_binaire[3], 2);
                }
            }
            MessageBox.Show("Votre masque sous-réseau en décimale est " + masque_decimale);
        }

        private void btn_adresseR_Click(object sender, EventArgs e)
        {
            string adresse_reseau=""; // Variable qui stockera l'adresse réseau binaire
            string adresse_reseau_decimale = ""; // Variable qui stockera l'adresse réseau décimale
            for (int i = 0; i < 35; i++)
            {

                if (i == 8 || i == 17 || i == 26)
                {
                    adresse_reseau += ".";
                }
                else
                {
// Pour chaque valeur de l'adresse ip en binaire et le masque en binaire, si ils sont égales à 1, l'adresse réseau aussi.
                    if (Globale.adresse_ip_binaire.Substring(i, 1) == "1" && Globale.masque_binaire.Substring(i, 1) == "1") 
                    {
                        adresse_reseau += "1";
                    }
// Le reste des valeurs pour l'adresse réseau sera 0 car le cas du dessus est le seul cas où les bits sont égaux à 1
                    else
                    {
                        adresse_reseau += "0";
                    }
                }
            }
            // Sépare en tableau les parties binaire de l'adresse réseau
                    string[] partie_binaire = adresse_reseau.Split('.');
            // Comme tout à l'heure, sauf là j comme i déjà utilisé
            for (int j = 0; j < 7; j++) 
            {
                // Fonction qui convertit la base 2 en base 10 pour chaque valeur de l'adresse avec le j
                if (j == 1 || j == 3 || j == 5)
                        {
                            adresse_reseau_decimale += '.';
                        }
                        if (j == 0)
                        {
                            adresse_reseau_decimale += Convert.ToByte(partie_binaire[0], 2); 
                        }
                        if (j == 2)
                        {
                            adresse_reseau_decimale += Convert.ToByte(partie_binaire[1], 2);
                        }
                        if (j == 4)
                        {
                            adresse_reseau_decimale += Convert.ToByte(partie_binaire[2], 2);
                        }
                        if (j == 6)
                        {
                            adresse_reseau_decimale += Convert.ToByte(partie_binaire[3], 2);
                        }
                    }
                    MessageBox.Show("Votre adresse réseau est " + adresse_reseau_decimale);
        }

        private void btn_nbhote_Click(object sender, EventArgs e)
        {
        // 32 CIDR maximum - Cidr choisi le tout puissance 2 - 2, formule pour calculer le nombre d'hôtes
            short nbhote = (short)(Math.Pow((32 - Globale.CIDR),2)-2); 
            MessageBox.Show("Le nombre d'hôtes maximum est " +  nbhote); 
        }

        private void btn_classe_Click(object sender, EventArgs e)
        {
        // Vérifie la première partie de l'adresse IP pour déterminer la classe
            if (Convert.ToByte(Globale.partie_ip[0]) >= 240)
            {
                MessageBox.Show("L'adresse IP est de classe E");
            }
            else if(Convert.ToByte(Globale.partie_ip[0]) >= 224)
            {
                MessageBox.Show("L'adresse IP est de classe D");
            }
            else if (Convert.ToByte(Globale.partie_ip[0]) >= 192)
            {
                MessageBox.Show("L'adresse IP est de classe B");
            }
            else if (Convert.ToByte(Globale.partie_ip[0]) >= 128)
            {
                MessageBox.Show("L'adresse IP est de classe B");
            }
            else if (Convert.ToByte(Globale.partie_ip[0]) == 127)
            {
                MessageBox.Show("L'adresse IP est de classe local");
            }
            else
            {
                MessageBox.Show("L'adresse IP est de classe A");
            }
        }

        private void btn_nbSousReseaux_Click(object sender, EventArgs e)
        {
            byte cidr_temp = Globale.CIDR;
            short nb_sousreseaux; // Variable qui stocke le nombre de sous réseaux
            // Cas où le nombre de sous réseaux est égale à 2 puissance 0 soit 1, puis traite les autres cas
            if (cidr_temp==0 || cidr_temp==8 || cidr_temp==16 || cidr_temp==24 || cidr_temp == 32)
            {
                MessageBox.Show("Le nombre de sous réseaux est 1");
            }
            else if(cidr_temp > 24)
            {
                cidr_temp -= 24;
                nb_sousreseaux=(short)(Math.Pow(cidr_temp, 2));
                MessageBox.Show("Le nombre de sous réseaux est " + nb_sousreseaux);
            }
            else if (cidr_temp > 16)
            {
                cidr_temp -= 16;
                nb_sousreseaux = (short)(Math.Pow(cidr_temp, 2));
                MessageBox.Show("Le nombre de sous réseaux est " + nb_sousreseaux);
            }
            else if (cidr_temp > 8)
            {
                cidr_temp -= 8;
                nb_sousreseaux = (short)(Math.Pow(cidr_temp, 2));
                MessageBox.Show("Le nombre de sous réseaux est " + nb_sousreseaux);
            }
            else
            {
                nb_sousreseaux = (short)(Math.Pow(cidr_temp, 2));
                MessageBox.Show("Le nombre de sous réseaux est " + nb_sousreseaux);
            }
        }

        private void valeur_NvCIDR_ValueChanged(object sender, EventArgs e)
        {
            // Cas où la valeur est possible car le nouveau CIDR est inférieure ou égale à 32
            if (valeur_NvCIDR.Value + Globale.CIDR < 33)
            {
                btn_valideNvCIDR.Enabled = true;
                lb_CIDRerreur.Text = "";
            }
            else
            // Cas où la valeur est impossible car le nouveau CIDR est supérieure à 32
            {
                btn_valideNvCIDR.Enabled = false;
                lb_CIDRerreur.Text = "Erreur, nombre de bits attribués trop élevé par rapport à l'autre CIDR";
            }
            
        }

        private void btn_valideNvCIDR_Click(object sender, EventArgs e)
        {
            byte nv_cidr = 0;
            nv_cidr = (byte)(Globale.CIDR + valeur_NvCIDR.Value); // Additionne l'ancien et le nouveau CIDR
            MessageBox.Show("Le nouveau CIDR est donc " + nv_cidr);
        }
    }
}
