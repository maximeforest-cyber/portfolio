﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AP7IpEtSousRéseauxForestMaxime
{
    internal class Globale
    {
        public static string adresse_ip="";
        public static byte CIDR;
        public static bool verife_form2 = false;
        public static string masque_binaire = "";
        public static string[] partie_ip;
        public static string adresse_ip_binaire = "";
    }
}
