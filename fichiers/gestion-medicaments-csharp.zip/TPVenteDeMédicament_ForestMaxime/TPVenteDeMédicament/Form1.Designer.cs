﻿namespace TPVenteDeMédicament
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_addmedic = new System.Windows.Forms.Button();
            this.btn_sellmedic = new System.Windows.Forms.Button();
            this.btn_stockmedic = new System.Windows.Forms.Button();
            this.lb_menu = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_addmedic
            // 
            this.btn_addmedic.Location = new System.Drawing.Point(96, 165);
            this.btn_addmedic.Name = "btn_addmedic";
            this.btn_addmedic.Size = new System.Drawing.Size(136, 88);
            this.btn_addmedic.TabIndex = 1;
            this.btn_addmedic.Text = "Ajouter un médicament au stock";
            this.btn_addmedic.UseVisualStyleBackColor = true;
            this.btn_addmedic.Click += new System.EventHandler(this.btn_addmedic_Click);
            // 
            // btn_sellmedic
            // 
            this.btn_sellmedic.Location = new System.Drawing.Point(336, 165);
            this.btn_sellmedic.Name = "btn_sellmedic";
            this.btn_sellmedic.Size = new System.Drawing.Size(136, 88);
            this.btn_sellmedic.TabIndex = 3;
            this.btn_sellmedic.Text = "Vendre un médicament";
            this.btn_sellmedic.UseVisualStyleBackColor = true;
            this.btn_sellmedic.Click += new System.EventHandler(this.btn_sellmedic_Click);
            // 
            // btn_stockmedic
            // 
            this.btn_stockmedic.Location = new System.Drawing.Point(571, 165);
            this.btn_stockmedic.Name = "btn_stockmedic";
            this.btn_stockmedic.Size = new System.Drawing.Size(136, 88);
            this.btn_stockmedic.TabIndex = 4;
            this.btn_stockmedic.Text = "Voir le stock";
            this.btn_stockmedic.UseVisualStyleBackColor = true;
            this.btn_stockmedic.Click += new System.EventHandler(this.btn_stockmedic_Click);
            // 
            // lb_menu
            // 
            this.lb_menu.AutoSize = true;
            this.lb_menu.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_menu.Location = new System.Drawing.Point(342, 38);
            this.lb_menu.Name = "lb_menu";
            this.lb_menu.Size = new System.Drawing.Size(119, 46);
            this.lb_menu.TabIndex = 5;
            this.lb_menu.Text = "Menu";
            this.lb_menu.Click += new System.EventHandler(this.label1_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(296, 322);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(216, 88);
            this.button1.TabIndex = 6;
            this.button1.Text = "Quitter";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Green;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lb_menu);
            this.Controls.Add(this.btn_stockmedic);
            this.Controls.Add(this.btn_sellmedic);
            this.Controls.Add(this.btn_addmedic);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_addmedic;
        private System.Windows.Forms.Button btn_sellmedic;
        private System.Windows.Forms.Button btn_stockmedic;
        private System.Windows.Forms.Label lb_menu;
        private System.Windows.Forms.Button button1;
    }
}

