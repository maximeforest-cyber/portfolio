﻿namespace TPVenteDeMédicament
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_menu = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.nud_Doliprane = new System.Windows.Forms.NumericUpDown();
            this.nud_Spasfon = new System.Windows.Forms.NumericUpDown();
            this.nud_Ibuprophene = new System.Windows.Forms.NumericUpDown();
            this.nud_Efferalgan = new System.Windows.Forms.NumericUpDown();
            this.button1 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Doliprane)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Spasfon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ibuprophene)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Efferalgan)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_menu
            // 
            this.lb_menu.AutoSize = true;
            this.lb_menu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_menu.Location = new System.Drawing.Point(26, 33);
            this.lb_menu.Name = "lb_menu";
            this.lb_menu.Size = new System.Drawing.Size(678, 25);
            this.lb_menu.TabIndex = 6;
            this.lb_menu.Text = "Choissez les médicaments que vous souhaitez vendre et leur nombre";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(63, 119);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 26);
            this.label1.TabIndex = 7;
            this.label1.Text = "Doliprane";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(245, 119);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 26);
            this.label2.TabIndex = 8;
            this.label2.Text = "Spasfon";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(408, 119);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(133, 26);
            this.label3.TabIndex = 9;
            this.label3.Text = "Ibuprophène";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(603, 119);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(111, 26);
            this.label4.TabIndex = 10;
            this.label4.Text = "Efferalgan";
            // 
            // nud_Doliprane
            // 
            this.nud_Doliprane.Location = new System.Drawing.Point(59, 169);
            this.nud_Doliprane.Name = "nud_Doliprane";
            this.nud_Doliprane.Size = new System.Drawing.Size(120, 26);
            this.nud_Doliprane.TabIndex = 11;
            this.nud_Doliprane.ValueChanged += new System.EventHandler(this.nud_Doliprane_ValueChanged);
            // 
            // nud_Spasfon
            // 
            this.nud_Spasfon.Location = new System.Drawing.Point(235, 169);
            this.nud_Spasfon.Name = "nud_Spasfon";
            this.nud_Spasfon.Size = new System.Drawing.Size(120, 26);
            this.nud_Spasfon.TabIndex = 12;
            // 
            // nud_Ibuprophene
            // 
            this.nud_Ibuprophene.Location = new System.Drawing.Point(421, 169);
            this.nud_Ibuprophene.Name = "nud_Ibuprophene";
            this.nud_Ibuprophene.Size = new System.Drawing.Size(120, 26);
            this.nud_Ibuprophene.TabIndex = 13;
            // 
            // nud_Efferalgan
            // 
            this.nud_Efferalgan.Location = new System.Drawing.Point(594, 169);
            this.nud_Efferalgan.Name = "nud_Efferalgan";
            this.nud_Efferalgan.Size = new System.Drawing.Size(120, 26);
            this.nud_Efferalgan.TabIndex = 14;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(315, 252);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(130, 32);
            this.button1.TabIndex = 15;
            this.button1.Text = "Valider";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 378);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(653, 22);
            this.label5.TabIndex = 16;
            this.label5.Text = "Votre stock ajouté est de 0 Doliprane, 0 Efféralgan, 0 Ibuprophéne et 0 Spasfon. " +
    "";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(284, 304);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(191, 32);
            this.button2.TabIndex = 17;
            this.button2.Text = "Retour";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Green;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.nud_Efferalgan);
            this.Controls.Add(this.nud_Ibuprophene);
            this.Controls.Add(this.nud_Spasfon);
            this.Controls.Add(this.nud_Doliprane);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lb_menu);
            this.Name = "Form2";
            this.Text = "Vente de médicament";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nud_Doliprane)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Spasfon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ibuprophene)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Efferalgan)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_menu;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown nud_Doliprane;
        private System.Windows.Forms.NumericUpDown nud_Spasfon;
        private System.Windows.Forms.NumericUpDown nud_Ibuprophene;
        private System.Windows.Forms.NumericUpDown nud_Efferalgan;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button2;
    }
}