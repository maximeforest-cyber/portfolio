﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TPVenteDeMédicament
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (nud_Doliprane.Value == 0 && (int)nud_Efferalgan.Value == 0 && nud_Spasfon.Value == 0 && nud_Ibuprophene.Value == 0)
            {
                MessageBox.Show("Erreur, aucun médicament ajouté");
            }
            else
            {
                MessageBox.Show("Ajout effectué");
                Globale.nb_doliprane += (int)nud_Doliprane.Value;
                Globale.nb_efferalgan += (int)nud_Efferalgan.Value;
                Globale.nb_spasfon += (int)nud_Spasfon.Value;
                Globale.nb_ibuprophene += (int)nud_Ibuprophene.Value;
                label5.Text = "Votre stock stock ajouté est de " + Globale.nb_doliprane.ToString() + " Doliprane(s), " + Globale.nb_efferalgan.ToString() + " Efféralgan(s), " + Globale.nb_ibuprophene.ToString() + " Ibuprophène(s) et " + Globale.nb_spasfon.ToString() + " Spasfon(s).";
                Globale.total_doliprane += (int)nud_Doliprane.Value;
                Globale.total_efferalgan += (int)nud_Efferalgan.Value;
                Globale.total_ibuprophene += (int)nud_Spasfon.Value;
                Globale.total_spasfon += (int)nud_Ibuprophene.Value;
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Globale.nb_doliprane = 0;
            Globale.nb_efferalgan = 0;
            Globale.nb_spasfon = 0;
            Globale.nb_ibuprophene = 0;
            Form1 form1suivant = new Form1();
            form1suivant.Show();
            this.Hide();

        }

        private void nud_Doliprane_ValueChanged(object sender, EventArgs e)
        {
  
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            

        }
    }
}
