﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TPVenteDeMédicament
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Form4_Load(object sender, EventArgs e)
        {
            if (Globale.total_doliprane == 0 && Globale.total_ibuprophene == 0 && Globale.total_spasfon == 0 && Globale.total_efferalgan == 0)
            {
                button1.Enabled = false;
                label6.Text = "Votre stock de médicament est nul, veuillez aller ajouter du stock pour pouvoir vendre des médicaments";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 form1suivant = new Form1();
            form1suivant.Show();
            this.Hide();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Globale.total_doliprane > (int)numericUpDown1.Value && Globale.total_spasfon > (int)numericUpDown2.Value && Globale.total_ibuprophene > (int)numericUpDown3.Value && Globale.total_efferalgan > (int)numericUpDown4.Value)
            {
                Globale.total_doliprane = Globale.total_doliprane - (int)numericUpDown1.Value;
                Globale.total_spasfon = Globale.total_spasfon - (int)numericUpDown2.Value;
                Globale.total_ibuprophene = Globale.total_ibuprophene - (int)numericUpDown3.Value;
                Globale.total_efferalgan = Globale.total_efferalgan - (int)numericUpDown4.Value;
            }
        }
    }
}
