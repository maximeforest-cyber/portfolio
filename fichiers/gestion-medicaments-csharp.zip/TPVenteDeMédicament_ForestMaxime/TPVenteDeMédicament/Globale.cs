﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPVenteDeMédicament
{
    internal class Globale
    {
        public static int nb_doliprane=0,nb_spasfon=0,nb_ibuprophene=0,nb_efferalgan=0,total_doliprane=0,total_spasfon=0,total_ibuprophene=0,total_efferalgan=0;
    }
}
